<?php
$n1 = 2;
$n2 = 3;

echo"somma ". $n1 +$n2;
echo "differenza".$n1 - $n2;
echo "prodotto".$n1 * $n2;
echo "prodotto".$n1 / $n2;

?>