<?php

$list = array("mus","giu","mau","mat");

foreach ($list as $key => $value) {
    # code...
    echo $value;
    echo '<br>';
}


?>