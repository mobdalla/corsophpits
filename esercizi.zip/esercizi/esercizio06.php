<?php
//Crea una funzione PHP che accetta due numeri come parametri e restituisce il loro prodotto. Chiama questa funzione e stampa il risultato.
 $num =3;
 $num1=3;
 $pd = prodotto($num,$num1);
 function prodotto($num,$num1){

    return $num * $num1;
 }

 echo($pd)

?>