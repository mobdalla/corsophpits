<?php 



foreach ( $_SERVER as $chiave => $valore ){

    echo $chiave.": ".$valore;
    echo '<br>';
}
?>