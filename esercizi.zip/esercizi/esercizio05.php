<?php 
//Scrivi uno script PHP che utilizza un ciclo while per stampare i numeri da 1 a 10.
$sc =10;
while ($sc <= 10) {
    # code...
    echo($sc);
    $sc-=1;
}

?>