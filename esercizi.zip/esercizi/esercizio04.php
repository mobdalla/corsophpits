
<?php 
//Crea uno script PHP che utilizza un ciclo for per stampare i numeri da 1 a 10.
for($i =0;$i<10; $i++){
    echo($i);
}
?>