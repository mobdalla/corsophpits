<?php

$persone = array("mus" => 23, "giu" => 20);

foreach ($persone as $key => $value) {
    # code...
    echo "Name: ".$key. "Age: ".$value;
}

?>