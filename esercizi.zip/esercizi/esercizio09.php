<?php 


$st="Mus";

echo "lunghezza di ".$st ." ".strlen($st); 

?>