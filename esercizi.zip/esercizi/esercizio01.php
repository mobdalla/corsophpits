<?php
 echo "hello, world!";
?>