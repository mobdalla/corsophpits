<form action="" method="post" >
    <input type="text" name="username" id="ussername">
    <input type="password" name="password" id="password">
    <input type="submit" value="Login">
</form>

<?php
foreach($_POST as $key => $value){
    echo "".$key.": ".$value."";
}

?>